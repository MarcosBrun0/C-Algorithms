//
// Created by Marcos Bruno Campos on 27/11/23.
//

#include "WordCount.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição da estrutura de um nó da árvore AVL
struct Node {
    char *word;
    int count;
    struct Node *left;
    struct Node *right;
    int height;
};


// Função para obter a altura de um nó
int height(struct Node *node) {
    if (node == NULL) {
        return 0;
    }
    return node->height;
}

// Função para calcular o fator de equilíbrio de um nó
int getBalance(struct Node *node) {
    if (node == NULL) {
        return 0;
    }
    return height(node->left) - height(node->right);
}

// Função para rotacionar à direita um subárvore com raiz em y
struct Node *rightRotate(struct Node *y) {
    struct Node *x = y->left;
    struct Node *T2 = x->right;

    // Realiza a rotação
    x->right = y;
    y->left = T2;

    // Atualiza alturas
    y->height = 1 + (height(y->left) > height(y->right) ? height(y->left) : height(y->right));
    x->height = 1 + (height(x->left) > height(x->right) ? height(x->left) : height(x->right));

    return x;
}

// Função para rotacionar à esquerda um subárvore com raiz em x
struct Node *leftRotate(struct Node *x) {
    struct Node *y = x->right;
    struct Node *T2 = y->left;

    // Realiza a rotação
    y->left = x;
    x->right = T2;

    // Atualiza alturas
    x->height = 1 + (height(x->left) > height(x->right) ? height(x->left) : height(x->right));
    y->height = 1 + (height(y->left) > height(y->right) ? height(y->left) : height(y->right));

    return y;
}

// Função para criar um novo nó
struct Node *createNode(char *word) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->word = strdup(word);
    newNode->count = 1;
    newNode->left = newNode->right = NULL;
    newNode->height = 1;
    return newNode;
}

// Função para inserir uma palavra na árvore AVL
struct Node *insert(struct Node *node, char *word) {
    if (node == NULL) {
        return createNode(word);
    }

    int compareResult = strcmp(word, node->word);

    // Realiza a inserção padrão de uma ABB
    if (compareResult < 0) {
        node->left = insert(node->left, word);
    } else if (compareResult > 0) {
        node->right = insert(node->right, word);
    } else {
        // Palavra já existe na árvore, incrementa a contagem
        node->count++;
        return node;
    }

    // Atualiza a altura do nó atual
    node->height = 1 + (height(node->left) > height(node->right) ? height(node->left) : height(node->right));

    // Obtém o fator de equilíbrio deste nó
    int balance = getBalance(node);

    // Casos de desequilíbrio

    // Rotação à esquerda-esquerda (LL)
    if (balance > 1 && compareResult < 0) {
        return rightRotate(node);
    }

    // Rotação à direita-direita (RR)
    if (balance < -1 && compareResult > 0) {
        return leftRotate(node);
    }

    // Rotação à esquerda-direita (LR)
    if (balance > 1 && compareResult > 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Rotação à direita-esquerda (RL)
    if (balance < -1 && compareResult < 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Percurso em-ordem (inorder)
void inOrderTraversal(struct Node *root) {
    if (root != NULL) {
        inOrderTraversal(root->left);
        printf("%s (%d) ", root->word, root->count);
        inOrderTraversal(root->right);
    }
}

// Libera a memória alocada para a árvore AVL
void freeTree(struct Node *root) {
    if (root != NULL) {
        freeTree(root->left);
        freeTree(root->right);
        free(root->word);
        free(root);
    }
}

// ... (código anterior)

int main() {
    struct Node *avlRoot = NULL;
    FILE *file = fopen("test.txt", "r");

    if (file == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo.\n");
        return 1;
    }

    char word[100];  // Assumindo que cada palavra tem no máximo 100 caracteres

    // Lê palavras do arquivo e insere na árvore AVL
    while (fscanf(file, "%s", word) != EOF) {
        avlRoot = insert(avlRoot, word);
    }

    // Fecha o arquivo
    fclose(file);

    // Percorre e imprime a árvore em-ordem
    printf("AVL Tree (In-Order):\n");
    inOrderTraversal(avlRoot);
    printf("\n");

    // Libera a memória alocada para a árvore AVL
    freeTree(avlRoot);

    return 0;
}

#include "cilindro.h"
#include <stdbool.h>
#include <stdio.h>

int main(void) {
  bool script_is_on = true;
  int options;
  Cilindro *c;
  float area;
  float volume;

  printf(" 1 para criar cilindro; \n 2 para area;\n 3 para volume;\n 4 para "
         "modificar cilindro;\n 5 para apagar cilindro;\n 6 para encerrar "
         "programa.\n");

  while (script_is_on) {
    scanf("%d", &options);
    switch (options) {
    case 1:
      c = cria_cilindro(10, 2, 5);
      break;
    case 2:
      area = Area(c);
      printf("area: %f \n", area);
      break;
    case 3:
      volume = vol(c);
      printf("volume: %f \n", volume);
      break;
    case 4:
      modcilin(c);
      break;
    case 5:
      limpar(c);
      break;
    case 6:
      script_is_on = false;
    }
  }
}
